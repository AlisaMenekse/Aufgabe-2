 create table Person (
	PersonID bigint primary key,
	firstname varchar(50) not null,
	lastname varchar(50) not null,
	dateOfBirth date not null
);

create table Patient (
	PatientID bigint primary key,
	healthInsuranceNumber varchar(50) not null,
	healthInsuranceCompany varchar(50) not null,
	foreign key (PatientID) references Person (PersonID)
		on update cascade
		on delete cascade
);

create table Physician (
	PhysicianID bigint not null primary key,
	SuperiorID bigint,
	WardID bigint not null,
	DepartmentID bigint not null,
	academicDegree varchar(50) not null,
    foreign key (PhysicianID) references Person (PersonID)
		on update cascade
		on delete cascade,
	foreign key (SuperiorID) references Physician (PhysicianID)
		on update cascade
		on delete set null
);

create table Nurse(
	NurseID bigint primary key,
	SuperiorID bigint,
	WardID bigint not null,
	foreign key (NurseID) references Person (PersonID)
		on update cascade
		on delete cascade,
	foreign key (SuperiorID) references Nurse (NurseID)
		on update cascade
		on delete set null
);

create table HospitalStay(
	HospitalStayID bigint primary key,
	PatientID bigint not null,
	WardID bigint not null,
	admissionDate date,
	dischargeDate date,
    foreign key (PatientID) references Patient (PatientID)
		on update cascade
		on delete restrict
);

create table Ward(
	WardID bigint primary key,
	DepartmentID bigint not null,
	name varchar(50) not null,
	numberOfBeds integer not null
);

create table Department(
	DepartmentID bigint primary key,
	name varchar(50) not null
);

create table Finding(
	FindingID bigint primary key,
	PhysicianID bigint not null,
	PatientID bigint not null,
	date date not null,
	summary varchar(200) not null,
	foreign key (PhysicianID) references Physician (PhysicianID)
		on update cascade
		on delete restrict,
	foreign key (PatientID) references Patient (PatientID)
        	on update cascade
        	on delete restrict
);

create table FindingDiagnosisPair(
	FindingID bigint not null,
	DiagnosisID bigint not null,
	primary key(FindingID, DiagnosisID),
	foreign key (FindingID) references Finding (FindingID)
		on update cascade
		on delete restrict
);

create table Diagnosis(
	DiagnosisID bigint primary key,
	ICDCode varchar(100)not null,
	diagnosis varchar(200)not null
);

create table ExaminationResult(
	ExaminationResultID bigint primary key,
	FindingID bigint not null,
	DiagnosticProcedureID bigint not null,
	summary varchar(200) not null,
	requestDate date not null,
	resultDate date,
	foreign key (FindingID) references Finding (FindingID)
		on update cascade
		on delete restrict
        
);

create table DiagnosticProcedure(
	DiagnosticProcedureID bigint primary key,
	SuperiorID bigint,
	name varchar(50) not null,
	bodyPart varchar(50),
	testType varchar(50),
	standardValue varchar(50),
	procedure varchar(50) not null,
	foreign key (SuperiorID) references DiagnosticProcedure (DiagnosticProcedureID)
		on update cascade
		on delete set null
); 

alter table Physician add foreign key (WardID) references Ward (WardID)
	on update cascade
	on delete restrict;
alter table Physician add foreign key (DepartmentID) references Department (DepartmentID)
	on update cascade
	on delete restrict;
alter table Nurse add foreign key (WardID) references Ward (WardID)
	on update cascade
	on delete restrict;
alter table HospitalStay add foreign key (WardID) references Ward (WardID)
   	on update cascade
   	on delete restrict;
alter table Ward add foreign key (DepartmentID) references Department (DepartmentID)
	on update cascade
	on delete restrict;
alter table FindingDiagnosisPair add foreign key (DiagnosisID) references Diagnosis (DiagnosisID)
	on update cascade
	on delete restrict;
alter table ExaminationResult add foreign key (DiagnosticProcedureID) references DiagnosticProcedure (DiagnosticProcedureID)
        on update cascade
        on delete restrict;
