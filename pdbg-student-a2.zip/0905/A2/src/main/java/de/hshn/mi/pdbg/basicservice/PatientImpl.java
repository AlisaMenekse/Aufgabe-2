package de.hshn.mi.pdbg.basicservice;

import de.hshn.mi.pdbg.basicservice.HospitalStay;
import de.hshn.mi.pdbg.basicservice.Patient;
import de.hshn.mi.pdbg.exception.StoreException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class PatientImpl extends PersonImpl implements Patient {
    String healthInsurance;
    String InsuranceNumber;
    String lastname;
    String firstname;
    Date dateOfBirth;
    Set<HospitalStay> hospitalStays = new HashSet<>();

    protected PatientImpl(BasicDBService service, long id) {
        super(service, id);
    }

    @Override
    public void setHealthInsurance(String name) {

    }

    @Override
    public void setInsuranceNumber(String number) {

    }

    @Override
    public String getHealthInsurance() {
        return healthInsurance;
    }

    @Override
    public String getInsuranceNumber() {
        return InsuranceNumber;
    }

    @Override
    public Set<HospitalStay> getHospitalStays() {
        return hospitalStays;
    }

    @Override
    public String getLastname() {
        return lastname;
    }

    @Override
    public void setLastname(String lastname) {

    }

    @Override
    public String getFirstname() {
        return firstname;
    }

    @Override
    public void setFirstname(String firstname) {
        assert firstname != null;
        assert firstname.isEmpty();
        //bei allen, nochmal in die doc schauen
        this.firstname = firstname;

    }

    @Override
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    @Override
    public void setDateOfBirth(Date dateOfBirth) {

    }

    @Override
    public long store(Connection connection) throws SQLException {
        try {
            connection.setAutoCommit(false);
            if (isPersistent()) {
                //insertstatement
                String statement = "insert into patient(id,healthinsurancenumber,healthinsurancecompany) values (?,?,?);";
                PreparedStatement preparedStatement = connection.prepareStatement(statement);
                preparedStatement.setLong(1, this.generateID(connection));
                preparedStatement.setString(2, this.getInsuranceNumber());
                preparedStatement.setString(3, this.getHealthInsurance());
                ResultSet resultSet = preparedStatement.executeQuery();
                super.store(connection);
                if (resultSet.next()) {
                    return resultSet.getLong(1);
                } else throw new StoreException("would not store");

            } else {
                String statement = "update patient set healthinsurancenumber= ?,healthinsurancecompany= ?;";
                PreparedStatement preparedStatement = connection.prepareStatement(statement);
                preparedStatement.setString(2, this.getInsuranceNumber());
                preparedStatement.setString(3, this.getHealthInsurance());
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    return resultSet.getLong(1);

                } else throw new StoreException("would not update");
            }

        }
        catch (SQLException exception){
            connection.rollback();
        throw new StoreException("transaction error");
        }
        finally {
            connection.setAutoCommit(true);
        }

    }
}
