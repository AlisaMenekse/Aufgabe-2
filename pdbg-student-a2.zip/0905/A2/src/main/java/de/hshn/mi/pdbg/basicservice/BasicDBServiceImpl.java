package de.hshn.mi.pdbg.basicservice;

import de.hshn.mi.pdbg.PersistentObject;
import de.hshn.mi.pdbg.basicservice.BasicDBService;
import de.hshn.mi.pdbg.basicservice.HospitalStay;
import de.hshn.mi.pdbg.basicservice.Patient;
import de.hshn.mi.pdbg.basicservice.Ward;
import de.hshn.mi.pdbg.exception.StoreException;
import org.eclipse.swt.internal.ole.win32.IPersist;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class BasicDBServiceImpl implements BasicDBService {
    Connection connection;

    public BasicDBServiceImpl(Connection con) {
        connection = con;
    }

    @Override
    public Patient createPatient(String lastname, String firstname) {
    PatientImpl patient = new PatientImpl(this, PersistentObject.INVALID_OBJECT_ID);
    patient.setFirstname( firstname);
    patient.setLastname(lastname);
        return patient;
    }

    @Override
    public Ward createWard(String name, int numberOfBeds) {
        WardImpl ward = new WardImpl(this, PersistentObject.INVALID_OBJECT_ID);
        ward.setName(name);
        ward.setNumberOfBeds(numberOfBeds);
        return ward;
    }

    @Override
    public HospitalStay createHospitalStay(Patient p, Ward s, Date admissionDate) {
        HospitalStayImpl hospitalStay = new HospitalStayImpl(this, PersistentObject.INVALID_OBJECT_ID);
        hospitalStay.setAdmissionDate(admissionDate);
        return hospitalStay;
    }

    @Override
    public void removeHospitalStay(long hospitalStayID) {

    }

    @Override
    public List<Patient> getPatients(String lastname, String firstname, Date startDate, Date endDate) {
        return null;
    }

    @Override
    public Patient getPatient(long patientID) {
        return null;
    }

    @Override
    public List<Ward> getWards() {
        return null;
    }

    @Override
    public Ward getWard(long wardID) {
        return null;
    }

    @Override
    public List<HospitalStay> getHospitalStays(long patientID) {
        return null;
    }

    @Override
    public List<HospitalStay> getHospitalStays(long patientID, Date startDate, Date endDate) {
        return null;
    }

    @Override
    public double getAverageHospitalStayDuration(long wardID) {
        return 0;
    }

    @Override
    public int getAllocatedBeds(Ward ward) {
        return 0;
    }

    @Override
    public int getFreeBeds(Ward ward) {
        return 0;
    }

    @Override
    public long store(PersistentObject object) {
        try {
            ((AbPersJDBCobj)object).store(connection);
            return object.getObjectID();
        } catch (SQLException exception) {
            exception.printStackTrace();
            throw new StoreException("didn't store");
        }

    }

    @Override
    public void close() {

    }
}
