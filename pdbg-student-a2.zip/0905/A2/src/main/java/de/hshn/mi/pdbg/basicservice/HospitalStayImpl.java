package de.hshn.mi.pdbg.basicservice;

import de.hshn.mi.pdbg.basicservice.HospitalStay;
import de.hshn.mi.pdbg.basicservice.Patient;
import de.hshn.mi.pdbg.basicservice.Ward;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

public class HospitalStayImpl extends AbPersJDBCobj implements HospitalStay {
    Date admissionDate;
    Date dischargeDate;

    protected HospitalStayImpl(BasicDBService service, long id) {
        super(service, id);
    }

    @Override
    public Date getAdmissionDate() {
        return admissionDate;
    }

    @Override
    public void setAdmissionDate(Date date) {

    }

    @Override
    public Date getDischargeDate() {
        return dischargeDate;
    }

    @Override
    public void setDischargeDate(Date date) {

    }

    @Override
    public Ward getWard() {
        return null;
    }

    @Override
    public void setWard(Ward ward) {

    }

    @Override
    public Patient getPatient() {
        return null;
    }

    @Override
    public long getObjectID() {
        return 0;
    }

    @Override
    public long store(Connection connection) throws SQLException {
        return 0;
    }

    @Override
    public boolean isPersistent() {
        return false;
    }
}
