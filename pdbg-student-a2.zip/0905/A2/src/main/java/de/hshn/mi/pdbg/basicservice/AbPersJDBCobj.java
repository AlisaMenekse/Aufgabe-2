package de.hshn.mi.pdbg.basicservice;

import de.hshn.mi.pdbg.basicservice.jdbc.AbstractPersistentJDBCObject;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public  abstract class  AbPersJDBCobj extends AbstractPersistentJDBCObject {

    protected AbPersJDBCobj(BasicDBService service, long id) {
        super(service, id);
    }
    protected long generateID(Connection connection) throws SQLException {

        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("SELECT nextval('sequence);");
        if (rs.next()) {
            long i = rs.getLong( "nextval");
            statement.close();
            rs.close();
            return i;
        }
        else throw new SQLException("Can't generate ID");

    }
}
