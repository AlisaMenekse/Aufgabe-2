package de.hshn.mi.pdbg.basicservice;

import java.sql.Connection;
import java.sql.SQLException;

public class WardImpl extends AbPersJDBCobj implements Ward{

    int numberOfBeds;
    String name;
    public WardImpl (BasicDBService basicDBService, long id){
        super (basicDBService,id);
    }

    @Override
    public long store(Connection connection) throws SQLException {
        return 0;
    }

    @Override
    public int getNumberOfBeds() {
        return numberOfBeds;
    }

    @Override
    public void setNumberOfBeds(int numberOfBeds) {

    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {

    }

}
