package de.hshn.mi.pdbg.basicservice;

import de.hshn.mi.pdbg.basicservice.Person;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

public  class PersonImpl extends AbPersJDBCobj implements Person {
    String lastname;
    String firstname;
    Date dateOfBirth;

    protected PersonImpl(BasicDBService service, long id) {
        super(service, id);
    }

    @Override
    public long store(Connection connection) throws SQLException {
        return 0;
    }

    @Override
    public String getLastname() {
        return lastname;
    }

    @Override
    public void setLastname(String lastname) {

    }

    @Override
    public String getFirstname() {
        return firstname;
    }

    @Override
    public void setFirstname(String firstname) {

    }

    @Override
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    @Override
    public void setDateOfBirth(Date dateOfBirth) {

    }


}
