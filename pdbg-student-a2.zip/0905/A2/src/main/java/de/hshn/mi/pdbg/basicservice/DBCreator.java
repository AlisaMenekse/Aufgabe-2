package de.hshn.mi.pdbg.basicservice;

import de.hshn.mi.pdbg.schema.SchemaGenerator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public final class DBCreator implements SchemaGenerator {

   // protected static final String[] SQL_DDL_STATEMENTS = {

   // }

    //@Override
    //public boolean createDatabase(String jdbcUrl, String user, String password) {
       // return false;
   // }

    protected static final String[] SQL_DDL_STATEMENTS = {

            "create table Person (\n" +
                    "\tPersonID bigint primary key,\n" +
                    "\tfirstname varchar(50) not null,\n" +
                    "\tlastname varchar(50) not null,\n" +
                    "\tdateOfBirth date not null\n" +
                    ");\n" +
                    "\n",
            "create table Patient (\n" +
                    "\tPatientID bigint primary key,\n" +
                    "\thealthInsuranceNumber varchar(50) not null,\n" +
                    "\thealthInsuranceCompany varchar(50) not null,\n" +
                    "\tforeign key (PatientID) references Person (PersonID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete cascade\n" +
                    ");\n" +
                    "\n",
            "create table Physician (\n" +
                    "\tPhysicianID bigint not null primary key,\n" +
                    "\tSuperiorID bigint,\n" +
                    "\tWardID bigint not null,\n" +
                    "\tDepartmentID bigint not null,\n" +
                    "\tacademicDegree varchar(50) not null,\n" +
                    "\tforeign key (PhysicianID) references Person (PersonID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete cascade,\n" +
                    "\tforeign key (SuperiorID) references Physician (PhysicianID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete set null\n" +
                    ");\n" +
                    "\n",
            "create table Nurse(\n" +
                    "\tNurseID bigint primary key,\n" +
                    "\tSuperiorID bigint,\n" +
                    "\tWardID bigint not null,\n" +
                    "\tforeign key (NurseID) references Person (PersonID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete cascade,\n" +
                    "\tforeign key (SuperiorID) references Nurse (NurseID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete set null\n" +
                    ");\n" +
                    "\n",
            "create table HospitalStay(\n" +
                    "\tHospitalStayID bigint primary key,\n" +
                    "\tPatientID bigint not null,\n" +
                    "\tWardID bigint not null,\n" +
                    "\tadmissionDate date,\n" +
                    "\tdischargeDate date,\n" +
                    "\tforeign key (PatientID) references Patient (PatientID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete restrict\n" +
                    ");\n" +
                    "\n",
            "create table Ward(\n" +
                    "\tWardID bigint primary key,\n" +
                    "\tDepartmentID bigint not null,\n" +
                    "\tname varchar(50) not null,\n" +
                    "\tnumberOfBeds integer not null\n" +
                    ");\n" +
                    "\n",
            "create table Department(\n" +
                    "\tDepartmentID bigint primary key,\n" +
                    "\tname varchar(50) not null\n" +
                    ");\n" +
                    "\n",
            "create table Finding(\n" +
                    "\tFindingID bigint primary key,\n" +
                    "\tPhysicianID bigint not null,\n" +
                    "\tPatientID bigint not null,\n" +
                    "\tdate date not null,\n" +
                    "\tsummary varchar(200) not null,\n" +
                    "\tforeign key (PhysicianID) references Physician (PhysicianID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete restrict,\n" +
                    "\tforeign key (PatientID) references Patient (PatientID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete restrict\n" +
                    ");\n" +
                    "\n",
            "create table FindingDiagnosisPair(\n" +
                    "\tFindingID bigint not null,\n" +
                    "\tDiagnosisID bigint not null,\n" +
                    "\tprimary key(FindingID, DiagnosisID),\n" +
                    "\tforeign key (FindingID) references Finding (FindingID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete restrict\n" +
                    ");\n" +
                    "\n",
            "create table Diagnosis(\n" +
                    "\tDiagnosisID bigint primary key,\n" +
                    "\tICDCode varchar(100)not null,\n" +
                    "\tdiagnosis varchar(200)not null\n" +
                    ");\n" +
                    "\n",
            "create table ExaminationResult(\n" +
                    "\tExaminationResultID bigint primary key,\n" +
                    "\tFindingID bigint not null,\n" +
                    "\tDiagnosticProcedureID bigint not null,\n" +
                    "\tsummary varchar(200) not null,\n" +
                    "\trequestDate date not null,\n" +
                    "\tresultDate date,\n" +
                    "\tforeign key (FindingID) references Finding (FindingID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete restrict\n" +
                    ");\n" +
                    "\n",
            "create table DiagnosticProcedure(\n" +
                    "\tDiagnosticProcedureID bigint primary key,\n" +
                    "\tSuperiorID bigint,\n" +
                    "\tname varchar(50) not null,\n" +
                    "\tbodyPart varchar(50),\n" +
                    "\ttestType varchar(50),\n" +
                    "\tstandardValue varchar(50),\n" +
                    "\tprocedure varchar(50) not null,\n" +
                    "\tforeign key (SuperiorID) references DiagnosticProcedure (DiagnosticProcedureID)\n" +
                    "\t\ton update cascade\n" +
                    "\t\ton delete set null\n" +
                    ");\n" +
                    "\n",
            "alter table Physician add foreign key (WardID) references Ward (WardID)\n" +
                    "\ton update cascade\n" +
                    "\ton delete restrict;\n",
            "alter table Physician add foreign key (DepartmentID) references Department (DepartmentID)\n" +
                    "\ton update cascade\n" +
                    "\ton delete restrict;\n",
            "alter table Nurse add foreign key (WardID) references Ward (WardID)\n" +
                    "\ton update cascade\n" +
                    "\ton delete restrict;\n",
            "alter table HospitalStay add foreign key (WardID) references Ward (WardID)\n" +
                    "\ton update cascade\n" +
                    "\ton delete restrict;\n",
            "alter table Ward add foreign key (DepartmentID) references Department (DepartmentID)\n" +
                    "\ton update cascade\n" +
                    "\ton delete restrict;\n",
            "alter table FindingDiagnosisPair add foreign key (DiagnosisID) references Diagnosis (DiagnosisID)\n" +
                    "\ton update cascade\n" +
                    "\ton delete restrict;\n",
            "alter table ExaminationResult add foreign key (DiagnosticProcedureID) references DiagnosticProcedure (DiagnosticProcedureID)\n" +
                    "\ton update cascade\n" +
                    "\ton delete restrict;",
           "CREATE SEQUENCE IF NOT EXISTS sequence AS bigint INCREMENT BY 1 MINVALUE 1 NO MAXVALUE START 1 CACHE 1;"

    };

    public static void main(String[] args) throws Exception { // Specific to HsqlDB, Use PostgreSQL
        String url = "jdbc:postgresql://localhost:5432/pdbg-a2";
        new DBCreator().createDatabase(url, "postgres", "secret"); //passwort wieder postgres vor der abgabe
    }
    @Override
    public boolean createDatabase(String jdbcUrl, String user, String password) {
        try (Connection con = createConnection(jdbcUrl, user, password); Statement stmt = con.createStatement();){
            for (String s:SQL_DDL_STATEMENTS) {
                stmt.executeUpdate(s);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    protected Connection createConnection(String jdbcURL, String user, String password) throws ClassNotFoundException, SQLException {
        Class.forName(org.hsqldb.jdbcDriver.class.getName());
        Connection conHSQL_VM;
        conHSQL_VM = DriverManager.getConnection(jdbcURL, user, password);
        return conHSQL_VM;
    }
}
