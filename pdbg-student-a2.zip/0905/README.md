# Hinweise

Liebe Studierende,

bitte legen Sie Ihre Projekte nur in den **jeweiligen** Aufgabenverzeichnissen ab.

Falls Sie dies nicht beachten, kann dies zu **gravierenden** Problemen mit dem CI/CD Prozess und/oder der Entwicklungsumgebung (IDE) führen.

# Notes

Dear students,

please only place your projects in the **appropriate** assignment directories.

Failure to do so may result in problems with the CI/CD process and/or the development environment (IDE).
